from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__,static_url_path='/static')

# Load the machine learning model
model = pickle.load(open('Liver.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html')
@app.route('/predict', methods=['POST'])
def predict():
    # Get the user input
    prediction_class = ""
    prediction_message = ""
    
    # Get the user input
    age = float(request.form.get("1"))
    gender = int(request.form.get("2"))
    total_bilirubin = float(request.form.get("3"))
    direct_bilirubin = float(request.form.get("4"))
    alkaline_phosphotase = float(request.form.get("5"))
    alamine_aminotransferase = float(request.form.get("6"))
    Aspartate_Aminotransferase = float(request.form.get("7"))
    total_proteins = float(request.form.get("8"))
    albumin = float(request.form.get("9"))
    albumin_globulin_ratio = float(request.form.get("10"))

        # Create a feature vector from the user input
    user_input = [
        age, gender, total_bilirubin, direct_bilirubin,
        alkaline_phosphotase, alamine_aminotransferase, Aspartate_Aminotransferase,
        total_proteins, albumin, albumin_globulin_ratio]
#test_input=np.array([65,0,0.7,0.1,187,16,18,6.8,3.3,0.9],dtype=object).reshape(1,10)
         # Make a prediction using the loaded model
     # Make a prediction using the loaded model
    prediction = model.predict(np.array(user_input).reshape(1, -1))
    print(prediction)

    if prediction[0] == 2:
        prediction_class = "red"
        prediction_message = "You are at risk of liver disease."
    else:
        prediction_class = "green"
        prediction_message = "You are not at risk of liver disease."

        print("inside the model")

    return render_template("result.html", prediction_message=prediction_message, prediction_class=prediction_class,user_input=user_input)

if __name__ == "__main__":
    app.run(debug=True)
